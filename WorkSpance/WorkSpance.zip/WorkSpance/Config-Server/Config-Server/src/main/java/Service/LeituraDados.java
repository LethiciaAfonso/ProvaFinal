package telas;

import java.util.Scanner;

public interface LeituraDados {
    Model lerDados(Scanner paramScanner);
}
