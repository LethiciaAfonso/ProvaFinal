package app;

public final class Aplicacao {
    public static void main
    ( String param ArrayOfString){
        ControladorInput.obterInstancia().loopPrincipal();
    }
}