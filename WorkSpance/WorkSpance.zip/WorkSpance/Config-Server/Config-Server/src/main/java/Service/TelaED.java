package Telas;

import Repository.Repositoryone;
import java.util.Scanner;

public interface TelaED {
    void exibirDados(Scanner paramScanner, Repository<Model> paramRepository);
}